import keyMirror from 'keymirror';

export default keyMirror({
    REQUEST_NAVS: null,
    RECEIVE_NAVS: null
})
