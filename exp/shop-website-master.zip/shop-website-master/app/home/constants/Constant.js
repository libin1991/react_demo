
export const REQUEST_NAV_URL = 'http://rapapi.net/mockjs/729/home/nav';
