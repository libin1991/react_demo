# shop-website
## 项目介绍
使用react及redux搭建一个电商网站，数据通过mockjs生成。

##  使用到的技术
> react

> redux

> react-router

> mockjs

> webpack

